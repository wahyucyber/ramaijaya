# ConvertExcelToJSON

This will tells you how we can create a JSON object from an uploaded Excel file to the browser.

For further understanding please refer :

https://medium.com/swlh/how-to-convert-excel-data-into-json-object-using-javascript-1c4e0d3e97ee
